# Linkivo

A fast, private link manager (PWA). Plain JavaScript, Firebase and a Cloudflare Worker, all on free tiers.

- App: https://linkivo.web.app
- Developer: Muhtasim Rahman, https://mdturzo.web.app

**Status:** v2.1.0 (foundation and shell): sign-in and guest mode, navigation, settings, data engines, database rules and the metadata Worker are in place. Library, import and the rest arrive in v2.2.0 to v2.6.0; the full README arrives with v2.6.0.

## Repository layout

| Path | What it is |
|---|---|
| `index.html`, `sw.js`, `app.json`, `firebase.json` | app shell, service worker, app info, hosting and database config |
| `css/`, `js/`, `assets/` | the app (split by page and function) |
| `@ Creator/` | project plan, rules, docs, tools and the AI build workflow (start with `PLAN.md`) |
| `@ Versions/` | one zip per released version |
