# Linkivo v1.4.5 — Upgrade Plan
### From: v1.4.4 → To: v1.4.5
**Planned:** 2026-04-03 | **Author:** Linkivo Dev

---

## Version Comparison Summary

| Version | Key Changes |
|---------|------------|
| v1.4.2 | Baseline — full feature set, cache issues, page overlap bugs |
| v1.4.3 | (skipped) |
| v1.4.4 | Tab fix (router display:none/flex), splash __hideSplash(), SW stale-while-revalidate, sidebar logo hover, locked folder DOM security, PIN gate on logout/reset |
| **v1.4.5** | This plan — major polish, new features, all remaining bugs fixed |

---

## What's DONE in v1.4.4 ✅

- ✅ Tab switching / page overlap → router explicit `display:none/flex` on all pages
- ✅ Splash screen stuck → `window.__hideSplash()` called from `showApp/showAuth`, 3s hard cap
- ✅ Boot crash → fallback to auth page, splash always removed
- ✅ Service Worker update propagation → `SW_UPDATED` message, stale-while-revalidate for JS/CSS
- ✅ firebase.json → JS/CSS now `Cache-Control: max-age=0, must-revalidate` (not immutable)
- ✅ Sidebar collapse → logo hover shows burger icon, collapsed tooltips via `[data-tooltip]`
- ✅ Locked folder DOM security → locked folders render NO sensitive content in DOM
- ✅ PIN gate on Logout / Reset Settings / Delete Account

---

## Known Bugs in v1.4.4 ❌

| # | Bug | File | Cause |
|---|-----|------|-------|
| B1 | `sw.js:120 clone() error` | sw.js | Response body consumed twice in stale-while-revalidate |
| B2 | `firebase-config.js MIME error` | firebase.json / firebase-config.js | File removed from `ignore` but placeholder served as HTML 404 → index.html |
| B3 | Popup renders twice (lag visible) | app.js, folders.js | No duplicate-guard on backdrop creation |
| B4 | Folder create popup doesn't auto-close | folders.js | `prompt()` resolution not cleaning modal |
| B5 | Mobile active/hover state sticks | base.css / components.css | No `@media (hover:none)` override — `:hover` acts as `:active` on touch |
| B6 | Preview fullscreen cuts content | random.js / links.js | iframe height not accounting for mobile safe area |
| B7 | History open creates new history entry | history.js | `addToHistory()` called from history page too |
| B8 | Loading screen stuck on live deploy | Multiple | firebase-config.js 404 → boot() crash → splash never removed (fixed partially) |

---

## Complete Feature List — Status

### 🔴 NOT YET DONE (v1.4.5 scope)

| # | Feature | Priority | Part |
|---|---------|----------|------|
| F1 | sw.js Response.clone() bug fix | CRITICAL | 1 |
| F2 | firebase-config.js MIME fix strategy | CRITICAL | 1 |
| F3 | Loading screen animation (typing effect, version shown) | HIGH | 1 |
| F4 | Login page scroll (content cut on small screens) | HIGH | 1 |
| F5 | URL routing: `/` paths instead of `#hash` | MEDIUM | 2 |
| F6 | Recycle Bin → full page (not popup) | HIGH | 2 |
| F7 | Mobile hardware back button → closes popup | HIGH | 2 |
| F8 | Mobile auto-rotate prevent | MEDIUM | 2 |
| F9 | Tab switch resets search results | HIGH | 2 |
| F10 | Mobile More section: 2 more buttons, drag sheet | MEDIUM | 2 |
| F11 | Folder card redesign (premium feel) | HIGH | 3 |
| F12 | Folder search + filter bar | HIGH | 3 |
| F13 | Folder description on card (truncated) | HIGH | 3 |
| F14 | Folder custom icon (imgbb proxy upload) | HIGH | 3 |
| F15 | Folder → Random Discover primary button | HIGH | 3 |
| F16 | Domain filter dropdown inside folder view | MEDIUM | 3 |
| F17 | Grid view thumbnail (meta image → favicon) w/ skeleton | MEDIUM | 3 |
| F18 | Folder create popup auto-close fix | HIGH | 3 |
| F19 | Locked folder: content never loads from Firebase without PIN | CRITICAL | 3 |
| F20 | All folders share same PIN system (not per-folder) → WRONG — keep per-folder PIN | N/A | — |
| F21 | Random Discover → full v1.4.2 style + domain filter in filter panel | HIGH | 4 |
| F22 | History: locked folder data not fetched from Firebase without PIN | HIGH | 4 |
| F23 | History: open link doesn't create new history entry | HIGH | 4 |
| F24 | History: delete → 2-sec undo toast (no confirm needed) | HIGH | 4 |
| F25 | History: clear all → confirmation + 5-sec undo toast | HIGH | 4 |
| F26 | History: 3-dot menu (clear, filter options) | MEDIUM | 4 |
| F27 | App lock PIN → Firebase sync (like folder PIN), 4-digit, auto-verify on 4th digit | HIGH | 5 |
| F28 | Forget PIN → email flow (auto-generate random PIN, email to user) | HIGH | 5 |
| F29 | PIN input UI: no password manager, 4/6 dot display, auto-submit | HIGH | 5 |
| F30 | Import popup: remove Paste tab, add paste button + textarea in File tab | HIGH | 6 |
| F31 | Import popup: cancel → confirmation, backdrop click → hide (state preserved) | HIGH | 6 |
| F32 | Preview: iframe → og:image → favicon fallback, status indicator | HIGH | 6 |
| F33 | Preview fullscreen fix (mobile safe area) | HIGH | 6 |
| F34 | Profile section overhaul (stats, links, history, quick actions) | HIGH | 7 |
| F35 | Profile photo: crop (1:1) + compress + imgbb upload, photo history | HIGH | 7 |
| F36 | Settings: app PIN + folder PIN management + password change | HIGH | 7 |
| F37 | Settings: theme/accent/font responsive (small screen) | MEDIUM | 7 |
| F38 | Settings: Firebase sync for ALL settings (not just some) | HIGH | 7 |
| F39 | Settings: clear history icon missing | LOW | 7 |
| F40 | App lock timer: immediately, 1, 5, 10, 30 min, 1hr | MEDIUM | 7 |
| F41 | Contact email in App Info | LOW | 7 |
| F42 | Privacy/Terms/Docs pages fix (blank page bug) | HIGH | 7 |
| F43 | Global search bar in header (cross-folder, navigate to result) | HIGH | 8 |
| F44 | New gradient logo (single SVG, both light+dark) | HIGH | 8 |
| F45 | README.md update (full v1.4.5 features) | MEDIUM | 8 |
| F46 | Sidebar recycle bin count badge | LOW | 8 |
| F47 | Sidebar icon alignment fix | LOW | 8 |
| F48 | Loading screen version number display | LOW | 1 |
| F49 | Replace emoji with FA icons throughout | MEDIUM | 8 |
| F50 | imgbb Cloudflare Workers proxy integration | HIGH | 3,7 |

---

## Part Breakdown

---

### PART 0 — Analysis & Planning (Current) ✅
**Output:** `plan.md`, `info.md`, gradient logo SVG
**Goal:** Complete understanding of codebase, all requirements categorized, execution order decided.

---

### PART 1 — Critical Fixes & Loading Experience
**Files:** `sw.js`, `firebase.json`, `index.html`, `assets/css/auth.css`, `assets/css/base.css`, `app.json`
**Version bump:** patches only (no JS logic changes, just bugs)

**Tasks:**
1. **sw.js clone() fix** — stale-while-revalidate: clone before serving, fix response consumption order
2. **firebase-config.js MIME fix** — Add a `firebase-config.js` build strategy note + make app gracefully handle missing config (show "configuration missing" screen instead of crashing and being stuck on splash)
3. **Loading screen animation:**
   - Icon fades in → app name types in character-by-character (CSS animation, `--typing-duration: 1.8s`, `--typing-delay: 0.4s` — user can tweak these 2 vars)
   - Version number shown below name (`data-app-version`)
   - Smooth fade-out when app ready
4. **Login page scroll** — `auth-container` uses `min-height: 100dvh`, `overflow-y: auto`, content centered with flex but scrollable when needed
5. **Splash stuck fallback** — additional guard: if `firebase-config.js` fails to load (MIME/404), show "Setup required" card instead of infinite splash
6. **Version update** → all `v1.4.4` → `v1.4.5` across all files

**Acceptance:** Fresh deploy → splash shows animation → app loads → no MIME errors in console. Old deploy → SW detects update → reloads once.

---

### PART 2 — Navigation, Routing & Mobile UX
**Files:** `router.js`, `index.html`, `assets/css/nav.css`, `assets/css/base.css`, `assets/js/app.js`, `links.js`

**Tasks:**
1. **URL paths** — Change hash routes to `/` paths using History API (`/`, `/random`, `/history`, `/settings`, `/folder/:id`). firebase.json already has `**` → `index.html` rewrite. Update router `_parseHash` → `_parsePath`. Update all `#route` links.
2. **Recycle Bin → Full Page** — Register `recycleBin` as a Router page. Give it its own `#page-recyclebin` div. Full-page layout with search bar, select-all, multi-select, restore/delete actions (matching folder section style). Remove popup approach. Add sidebar nav item.
3. **Mobile back button** — `window.addEventListener('popstate')` already handles back. Add: if any modal/backdrop is open, intercept back and close it instead. Push a dummy state when modals open.
4. **Mobile auto-rotate** — Add `<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">` + CSS `@media screen and (orientation: landscape) { ... }` fix for key mobile layouts.
5. **Tab switch resets search** — Each page module saves its search/filter state (`_filter`) in `Storage` keyed by page. On `onLeave` save, on `onEnter` restore.
6. **Mobile More sheet** — Add 2 more items (Import, Recycle Bin already there; add Global Search, Folder Create). Make it a proper drag-up bottom sheet with handle.
7. **Mobile hover/active fix** — `@media (hover: none) { .btn:hover { background: initial; } }` — only real clicks apply active state, reset on `touchend`.
8. **Popup duplicate guard** — All backdrop creation functions: `document.getElementById('X-backdrop')?.remove()` before creating (already partially done, audit all).

**Acceptance:** Back button closes modals. Pages switch cleanly. URLs update to `/random` etc. Recycle bin is a full page.

---

### PART 3 — Folder System Overhaul
**Files:** `folders.js`, `assets/css/folder.css`, `assets/css/home.css`, `assets/js/links.js`, `assets/css/links.css`

**Tasks:**
1. **Folder card redesign:**
   - Equal height cards using CSS Grid (`grid-template-rows`)
   - Color accent bar on left edge (3px)
   - Icon in top-left with background circle
   - Description below name (max 2 lines, `text-overflow: ellipsis`)
   - Stats row: link count, time ago, tags
   - Pinned badge top-right
   - No giant "Locked" text — just a small lock icon overlay with slight opacity
   - Hover: subtle lift `translateY(-2px)` + shadow

2. **Locked folder — data never loads without PIN:**
   - `openFolderView()` — if locked AND not session-unlocked: show PIN prompt BEFORE any Firebase call
   - `_renderLocked()` replaces current page with PIN form — no data fetched
   - History page: locked folder entries show "Content locked" placeholder text, no URL/title — fetch folders first, check lock status, only show real data for unlocked folders

3. **Folder search + filter bar:**
   - Search input (debounced 200ms) filters folder names + descriptions
   - Dropdown filter: All / Pinned / Locked / By color tag
   - Count badge: "Showing X of Y"

4. **Folder description on card:**
   - Stored in Firebase (already is)
   - Show on card: 2-line clamp
   - Full description in folder header when opened, with "Show more / Show less"

5. **Folder create popup auto-close:**
   - After successful `createFolder()`, call `close()` explicitly
   - Add loading spinner on create button while saving

6. **Folder → Random Discover button:**
   - Primary floating button inside folder header (not just 3-dot menu)
   - Click → `Router.go('random')` + dispatch `linkivo:openRandomWithFolder` event with `folderId`
   - On Random page: listen for event, auto-select that folder, auto-pick first link

7. **Folder custom icon (imgbb proxy):**
   - Icon picker popup: 3 rows of preset FA icons (12 icons: folder, link, star, heart, bookmark, code, book, music, film, gamepad, briefcase, globe)
   - "+ Upload Image" button → file input → compress to 128×128 JPEG (using Canvas API) → POST to `https://linkivo.programs-turzo.workers.dev/` → get imgbb URL → update folder `iconUrl` in Firebase
   - If `iconUrl` exists: show `<img>` instead of FA icon in folder card

8. **Domain filter in folder view:**
   - Add a domains dropdown (multi-select) next to sort dropdown
   - Auto-populated from unique domains in current folder's links
   - Custom dropdown component (checkboxes, "Select all")

9. **Grid view thumbnail:**
   - When rendering link card in grid mode: check if `link.thumbnailUrl` exists → show as background image
   - Skeleton loading animation (`@keyframes shimmer`)
   - On import: do NOT fetch thumbnail (too slow) — fetch lazily when grid view is first rendered using `IntersectionObserver`
   - Use `/linkivo.programs-turzo.workers.dev/?action=og&url=...` OR just use `https://linkpreview.net/...` as fallback
   - Save `thumbnailUrl` to Firebase on first successful fetch

**Acceptance:** Folder cards look polished. Locked folders never expose data. Search works. Create popup closes. Icon picker works.

---

### PART 4 — Random Discover & History Fixes
**Files:** `random.js`, `history.js`, `assets/css/random.css`, `assets/css/history.css`

**Tasks:**

#### Random Discover:
1. **Restore v1.4.2 full layout:** folder selector + options panel + domain filter + preview section (resizable) + action buttons. The v1.4.4 version should not have broken this — verify and restore if different.
2. **Domain filter in filter panel:** Domain list auto-detected from selected folders' links. Multi-select custom dropdown. "Show more / Show less" if >6 domains.
3. **Preview advanced fallback chain:**
   - Step 1: Try `<iframe src="url">` → listen for load/error (3s timeout)
   - Step 2: If iframe blocked (error/timeout): fetch `og:image` from `https://linkivo.programs-turzo.workers.dev/?action=og&url={url}` 
   - Step 3: If og:image fails: show favicon (large) centered with gradient bg
   - Status indicator: small pill in preview corner showing "Loading…", "Preview", "Thumbnail", "Icon only" — auto-hides after 2s
4. **Preview fullscreen mobile fix:** `height: calc(100dvh - env(safe-area-inset-bottom))`, iframe gets remaining height after header/buttons

#### History:
1. **Locked folder data never fetched:** On subscribe, fetch folder list first. For each history item, if `folderId` maps to a locked+not-unlocked folder: replace with `{title: 'Locked Content', url: null, folderLocked: true}`. No actual link data fetched.
2. **History open → no new history:** Add `source: 'history'` flag when opening from history page. In `addToHistory()`, skip if `link.source === 'history'`.
3. **Delete → 2-sec undo toast:** On `[data-del]` click: store item in memory, remove from DOM immediately, show toast "Removed: {title} [Undo]" for 2s. If undo clicked: re-render item. If 2s passes: call Firebase remove. 
4. **Clear all → 5-sec undo:** Store all items in memory, clear DOM, show toast with countdown + undo for 5s. If undo: re-render, cancel delete. If 5s: single `remove()` call.
5. **History 3-dot menu:** Shows: "Clear all", "Export history", "Filter by folder", "Auto-clear settings" (opens settings section)

**Acceptance:** Random page looks and works like v1.4.2. History items from locked folders show placeholder. Undo works within time window.

---

### PART 5 — Security, PIN & Auth
**Files:** `utils.js`, `app.js`, `auth.js`, `settings.js`, `assets/css/auth.css`, `assets/css/components.css`

**Tasks:**
1. **App lock PIN → Firebase sync:**
   - Store in `users/{uid}/settings/appPin` (encrypted? at least not plain text — use simple XOR with uid as key, acceptable for this threat model)
   - 4-digit (app PIN) vs 6-digit (folder PIN) — enforced by `maxlength`
   - Auto-verify on 4th/6th digit (no submit button needed)
   - On `onAuthStateChanged`: load `appPin` from Firebase, store in `Storage` for offline use
   - PIN change syncs to Firebase immediately

2. **PIN input UI improvements:**
   - Type `password`, `inputmode="numeric"`, `autocomplete="off"`, `autocorrect="off"`, `autocapitalize="off"`, `data-lpignore="true"`, `data-1p-ignore="true"` — prevents Google/1Password interference
   - Dot indicator row: 4 dots (app) or 6 dots (folder) — animated fill
   - Auto-submit on last digit
   - Error shake animation on wrong PIN
   - No "Confirm" button needed — auto-submits

3. **Forget PIN flow:**
   - "Forgot PIN?" link below PIN input
   - Click → show info sheet explaining options:
     - **Option A (Recommended):** "Send PIN to your email" — generates new random 4/6-digit PIN, updates Firebase, sends email via `mailto:` link (pre-filled) to user's own email. Note: "Check spam folder if not received within 1 min"
     - **Option B:** "Contact support" — opens `mailto:linkivo.web@gmail.com` with pre-filled email template (user info auto-populated)
   - For email: PIN is regenerated and stored in Firebase first, THEN shown in email body. User forwards to themselves or just reads it.

4. **Email template (pre-filled `mailto:`):**
   ```
   To: linkivo.web@gmail.com
   Subject: PIN Reset Request — Linkivo App
   Body: [formatted as per prompt spec, all fields auto-populated]
   ```

5. **Password change (email users only):**
   - Settings → Security → "Change Password" (only shown for email provider)
   - Current password → new password → confirm → `updatePassword()` via Firebase Auth
   - Google users: show "Managed by Google" chip

6. **Sensitive action PIN gate audit:**
   - Logout ✅ (done in v1.4.4)
   - Reset Settings ✅ (done)
   - Delete Account ✅ (done)
   - Change Password → add PIN gate
   - Remove App Lock → requires current PIN

**Acceptance:** App PIN synced to Firebase. 4-digit auto-submits. Forget PIN sends email. No password manager interference.

---

### PART 6 — Import & Preview Overhaul
**Files:** `import.js`, `assets/css/import.css`, `random.js`, `links.js`, `assets/css/random.css`

**Tasks:**
1. **Import popup — paste UX:**
   - Remove the "Paste" tab entirely
   - In the File tab: below the dropzone, add a collapsible "Or paste text / URLs" section
   - Textarea (8 rows) with a floating "Paste" button (top-right corner of textarea) that calls `navigator.clipboard.readText()`
   - Link detection runs in real-time as user types (debounced 300ms) — shows "X links detected" badge
   - Rest of flow unchanged (folder select, import button, progress)

2. **Import cancel → confirmation:**
   - If any links detected: cancel button shows `confirm('Discard import?')` 
   - Backdrop click: just hides (not destroys) the modal → `display:none`
   - Re-open: restores previous state (detected links, selected folder)
   - State stored in module-level variables

3. **Preview advanced fallback chain:** (see Part 4 — Random section, same logic applies to Folder link preview in `links.js`)

4. **Preview fullscreen mobile fix:**
   - `--preview-height` CSS var driven by JS resizer
   - Mobile: use `100dvh` not `100vh`
   - Resizable panel: min `200px`, max `calc(100dvh - 120px)`

**Acceptance:** No Paste tab. Paste button in file tab works. Cancel preserves state. Preview shows something for all websites.

---

### PART 7 — Settings & Profile Overhaul
**Files:** `settings.js`, `assets/css/settings.css`, new `profile.js` (or extend `settings.js`), `assets/css/auth.css`

**Tasks:**
1. **Profile section overhaul:**
   - Profile page: full-screen slide-in (not bottom sheet) OR dedicated `#/profile` route
   - Sections:
     - **Header:** Avatar (large, tappable to change), display name (inline edit), email, provider badge, member since date
     - **Stats bar:** Folders, Links, History count — tappable → navigates to section
     - **Profile photos:** Horizontal scroll list of previously uploaded photos. Tap to use. Tap trash to delete from imgbb + Firebase list.
     - **Quick actions:** Edit name, Change password (email), Manage PINs (→ Security), Export data, Recycle bin
   - "Edit Display Name" → inline edit with save/cancel
   - Profile photo change → crop modal (using `cropperjs` CDN) → compress (Canvas) → imgbb upload via proxy → save URL to `users/{uid}/profile/photoURL` + `users/{uid}/profile/photoHistory[]` in Firebase → call `updateProfile(user, {photoURL: newUrl})`

2. **imgbb integration (Cloudflare Worker proxy):**
   - Worker URL: `https://linkivo.programs-turzo.workers.dev/`
   - For photo upload: `POST` with `FormData`, field `image` = base64 string, field `name` = `linkivo-{uid}-profile-{timestamp}`
   - For folder icon: `name` = `linkivo-{uid}-folder-{folderId}-{timestamp}`
   - Response: `{ data: { url: '...' } }`
   - Helper function `uploadToImgbb(base64, name)` in `utils.js`

3. **Settings responsive fixes:**
   - Theme toggle (dark mode switch) — full width on mobile
   - Accent swatches — flex-wrap on small screens
   - Font size buttons — full width row on mobile
   - Use `@container` or `@media (max-width: 400px)` queries

4. **Firebase sync for ALL settings:**
   - Current: some settings only saved to `localStorage`
   - Fix: ALL settings (showLinkUrls, openLinksNewTab, incognitoMode, historyMax, autoClearHistoryDays, accent, fontSize, theme) also saved to `users/{uid}/settings/`
   - On login: load from Firebase, override localStorage

5. **App lock timer:**
   - Options: "Immediately", "1 min", "5 min", "10 min", "30 min", "1 hour"
   - Stored in Firebase settings as `autoLockMin: 0 | 1 | 5 | 10 | 30 | 60` (0 = immediately on manual lock only, not auto)
   - Remove the old hard-coded "10-minute reload grace" — replace with proper timer

6. **Clear history icon fix** → add `<i class="fa-solid fa-trash-clock"></i>` or similar

7. **App info:** Add `linkivo.web@gmail.com` as contact email with `mailto:` link

8. **Privacy/Terms/Docs pages fix:**
   - Currently routes: `/privacy` → `/docs/privacy.html` etc. — firebase.json already has rewrites
   - Bug: the links in settings use `#` hash anchors or wrong paths
   - Fix: update Settings footer links to use proper paths `/privacy`, `/terms`, `/docs` (not anchor tags pointing nowhere)
   - Also update the `docs/*.html` files if they have broken internal links

9. **Emoji → Icons:** Audit entire codebase for hardcoded emoji (🔒📁🔗etc.) and replace with appropriate FA icons with consistent styling

**Acceptance:** Profile page rich with content. imgbb upload works. All settings synced to Firebase. Settings layout responsive. Privacy/Terms pages open correctly.

---

### PART 8 — Global Search, Logo, Polish & README
**Files:** `index.html`, `app.js`, new `search.js`, `assets/css/base.css`, `assets/svg/`, `README.md`, `info.md`

**Tasks:**
1. **Global search bar:**
   - Search icon in topbar (already has topbar area) → click → expands into full-width search input with backdrop
   - Search scope: folder names, link titles, link URLs, link domains
   - Results grouped: "Folders (3)", "Links (12)"
   - Click folder result → navigate to folder
   - Click link result → navigate to that folder AND scroll to that link + highlight (CSS `@keyframes highlight-pulse` on the card)
   - Keyboard: `Escape` closes, `↑/↓` navigates results, `Enter` selects
   - Tab switch clears search (already planned in Part 2)

2. **New gradient logo:**
   - Single SVG with `linearGradient` — gradient from `#3b82f6` → `#22d3ee` (135deg)
   - Works on any background (no fill dependency on bg color)
   - Three variants in one file using `<symbol>` or separate files:
     - `logo-gradient.svg` — full gradient (replaces light/dark variants)
     - `icon-gradient.svg` — icon only (for PWA splash, favicon)
   - Update `index.html` logo `<img>` tags — use single gradient version, remove light/dark swap logic

3. **README.md** — Complete rewrite:
   - v1.4.5 version badge
   - All features listed (import formats, export formats, point system, etc.)
   - Setup guide (Firebase config, deploy)
   - Architecture notes
   - Changelog since v1.0.0
   - NO sensitive data

4. **Final polish:**
   - Sidebar: recycle bin count badge (small `<span>` with count from Firebase)
   - Sidebar: icon vertical alignment audit (all items `align-items: center`)
   - Remove all hardcoded emoji, replace with FA icons
   - Mobile `orientation: landscape` CSS fix
   - Double-check all `v1.4.4` strings → `v1.4.5`

---

## File Change Summary

| File | Parts Touching | Change Type |
|------|---------------|-------------|
| `sw.js` | 1 | Bug fix (clone error) |
| `firebase.json` | 1 | Header fix |
| `index.html` | 1,2,8 | Splash animation, URL routing, search bar |
| `router.js` | 2 | Path-based routing |
| `app.js` | 2,5,8 | Back button, search, logo |
| `folders.js` | 3 | Card redesign, icon picker, search, locked security |
| `links.js` | 3,4,6 | Grid thumbnail, preview fallback, domain filter |
| `import.js` | 6 | Paste UI, cancel state |
| `random.js` | 4 | Full v1.4.2 restore, domain filter, preview |
| `history.js` | 4 | Locked data, undo toast, 3-dot menu |
| `settings.js` | 5,7 | PIN sync, profile, responsive, Firebase sync |
| `auth.js` | 5 | Password change |
| `utils.js` | 5,7 | uploadToImgbb(), pinDialog 4/6 digit, PIN auto-submit |
| `assets/css/nav.css` | 2,8 | Recycle bin badge, icon alignment |
| `assets/css/base.css` | 1,2 | Login scroll, mobile UX |
| `assets/css/folder.css` | 3 | Card redesign |
| `assets/css/random.css` | 4 | Preview layout |
| `assets/css/settings.css` | 7 | Responsive |
| `assets/css/components.css` | 2,5 | Mobile hover fix, PIN UI |
| `assets/css/history.css` | 4 | Undo toast |
| `assets/svg/` | 8 | Gradient logo |
| `README.md` | 8 | Complete rewrite |
| NEW: `assets/js/search.js` | 8 | Global search |
| NEW: `info.md` | 0 | App info reference |

---

## Execution Order

```
Part 0 (Plan) ─────── NOW ✅
Part 1 (Critical) ─── next — fixes must land before anything else
Part 2 (Navigation) ─ after Part 1 (routing affects everything)
Part 3 (Folders) ──── after Part 2
Part 4 (Random+Hist)─ can run parallel with Part 3
Part 5 (Security) ─── after Part 3 (PIN UI needs to be consistent)
Part 6 (Import+Preview)─ relatively independent, after Part 2
Part 7 (Settings) ─── after Part 5
Part 8 (Search+Logo)── last, polishes everything
```

---

## Git Commit Messages (end of each Part)

- **Part 0:** `chore: v1.4.5 planning — plan.md + info.md + gradient logo`
- **Part 1:** `fix(sw): resolve Response.clone error; fix loading animation, login scroll, version display`
- **Part 2:** `feat(nav): path routing, recycle bin full page, back button modal close, mobile UX fixes`
- **Part 3:** `feat(folders): card redesign, search/filter, icon picker, locked security, domain filter`
- **Part 4:** `fix(random,history): restore v1.4.2 random UI, history undo toast, locked data protection`
- **Part 5:** `feat(security): Firebase PIN sync, 4-digit app lock, forget PIN email, password change`
- **Part 6:** `feat(import,preview): paste UI overhaul, iframe→og→favicon preview fallback`
- **Part 7:** `feat(settings,profile): imgbb integration, profile overhaul, all settings Firebase-synced`
- **Part 8:** `feat(search): global search bar; chore: gradient logo, README rewrite, polish`

---

## Final Release: v1.4.5

**Release notes summary:**
- Global search across all folders and links
- Profile page overhaul with photo upload (imgbb)
- Folder custom icons via imgbb
- Random Discover restored to v1.4.2 quality
- History undo delete (2s window)
- App lock PIN synced to Firebase (4-digit)
- Forget PIN via email
- Full-page Recycle Bin
- Import paste UI improved
- Preview: iframe → og:image → favicon fallback
- Path-based routing (`/random` not `#random`)
- Loading animation with typing effect
- All settings Firebase-synced
- New gradient logo
- Complete README
