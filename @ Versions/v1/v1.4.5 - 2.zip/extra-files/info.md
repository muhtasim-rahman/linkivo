# Linkivo — App Information Reference
> This file is the single source of truth for all app metadata.
> Used for: SEO, social cards, app stores, README, settings page, docs.
> **Do not include sensitive data (API keys, UIDs, config values).**

---

## Identity

| Field | Value |
|-------|-------|
| **App Name** | Linkivo |
| **Short Name** | Linkivo |
| **Version** | v1.4.5 |
| **Build Date** | 2026-04-05 |
| **Type** | Progressive Web App (PWA) |
| **Platform** | Web (any modern browser), installable on iOS & Android |
| **Live URL** | https://linkivo.web.app |
| **Repo URL** | https://github.com/yourusername/linkivo |
| **Contact Email** | linkivo.web@gmail.com |
| **Twitter / X** | @linkivo_app |

---

## Taglines (5 alternatives)

1. **Save, organize, and randomly discover links — smarter.** *(primary)*
2. **Your links, organized. Discovered randomly.*
3. **The smart bookmark manager that surprises you.**
4. **Save links. Build collections. Discover something new.**
5. **Link management with a twist — randomness.**

---

## Descriptions

### Short (1–2 sentences, ~120 chars)
> Smart link manager with folders, import from 10+ formats, and a weighted random discovery engine.

### Medium (2–4 sentences, for app stores / social cards)
> Linkivo is a smart link management web app that lets you save, organize, and randomly discover saved links. Import from text files, PDFs, bookmarks, HTML, JSON, and more. Organize into folders with PIN-lock, favorites, and point-based weighting. Discover links you've forgotten — randomly.

### Long (full description, for README / landing page)
> Linkivo is a powerful, privacy-first link manager that runs entirely in your browser and syncs across all your devices via Firebase. Save links individually or import them in bulk from 10+ file formats including TXT, PDF, HTML, JSON, CSV, ZIP, Markdown, and browser bookmarks. Organize your links into color-coded, icon-customizable folders with optional PIN lock for sensitive collections.
>
> The heart of Linkivo is its Random Discover engine — a weighted probability system that surfaces links based on your engagement (likes, dislikes, stars, open count). Links you love rise to the top; links you've overused fade back. Browse with purpose or let serendipity take over.
>
> Linkivo works offline as a PWA, supports full dark/light/accent theming, and keeps your data secure with folder-level and app-level PIN locks. Export your data to JSON, CSV, PDF, HTML Bookmarks, or Markdown at any time. Your data, your control.

---

## Features List (ordered by value)

1. **Smart Random Discovery** — Weighted probability engine based on likes, stars, and open history
2. **Universal Import** — 10+ formats: TXT, PDF, HTML, JSON, CSV, ZIP, Markdown, Bookmarks, Images (OCR)
3. **Folder Organization** — Color-coded folders with custom icons, PIN lock, pin-to-top
4. **Point System** — Like (+50), Dislike (−40), Star (+100), open-count decay — influences random picks
5. **Embedded Preview** — iframe → og:image → favicon fallback chain with status indicator
6. **Recycle Bin** — 30-day soft delete for links and folders with restore
7. **Full History** — Searchable open history with date grouping, undo delete
8. **Export** — JSON, CSV, PDF, HTML Bookmarks, Markdown, Print
9. **Global Search** — Cross-folder search for links and folders with highlighted results
10. **App Lock** — 4-digit PIN with Firebase sync, auto-lock timer, forget PIN via email
11. **Folder Lock** — 6-digit per-folder PIN, session-based unlock, data never fetched without PIN
12. **Dark / Light Mode** — Full system preference support + manual toggle
13. **Accent Themes** — Blue, Purple, Green, Orange, Rose
14. **Font Size** — Small, Medium, Large
15. **PWA** — Install on mobile/desktop, offline-capable via Service Worker
16. **Real-time Sync** — Firebase Realtime Database, instant cross-device updates
17. **Profile Photos** — Upload, crop, imgbb-hosted, history of past photos
18. **Folder Custom Icons** — 12 preset icons + upload custom image (imgbb)
19. **Grid / List View** — Toggle for link display with meta-image thumbnails in grid mode
20. **Multi-select** — Bulk delete, bulk move across folders
21. **Grid Thumbnails** — Lazy og:image fetch, saved to Firebase, fallback to favicon
22. **Domain Filter** — Filter links by domain within folder view
23. **History Undo** — 2s single item undo, 5s clear-all countdown undo
24. **Forget PIN** — Pre-filled mailto: template for support request
25. **Path Routing** — Clean URLs `/random` `/history` `/folder/:id`
26. **Full-page Recycle Bin** — Search, multi-select, bulk restore/delete
21. **Auto-advance** — Random page auto-picks next link on a timer

---

## Supported Import Formats

`TXT` `PDF` `HTML` `JSON` `CSV` `ZIP` `PNG` `JPG` `JPEG` `WEBP` `Bookmarks` `HTM` `MD`

## Export Formats

`JSON` `CSV` `PDF` `HTML Bookmarks` `Markdown` `Print`

---

## Point System Reference

| Action | Effect |
|--------|--------|
| Base | 100 pts |
| Like | +50 pts |
| Dislike | −40 pts |
| Star/Favourite | +100 pts |
| Blocked | 0 pts (excluded from random) |
| Open count > 10 | ×max(0.4, 1−(count−10)×0.02) decay |

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | Pure HTML5 + CSS3 + ES Modules (no framework) |
| Auth | Firebase Authentication (Google + Email/Password) |
| Database | Firebase Realtime Database |
| Hosting | Firebase Hosting |
| Offline | Service Worker (cache-first + stale-while-revalidate) |
| Image hosting | ImgBB via Cloudflare Worker proxy |
| Icons | Font Awesome 6 |
| Fonts | Outfit, DM Sans (Google Fonts) |
| PDF import | pdf.js (CDN) |
| Image OCR | Tesseract.js (CDN) |
| Image crop | Cropper.js (CDN) |

---

## Data Model (Firebase Realtime DB)

```
users/{uid}/
  profile/
    displayName, email, photoURL
    photoHistory: [{url, uploadedAt}]
    createdAt
  settings/
    theme, accent, fontSize
    showLinkUrls, openLinksNewTab, incognitoMode
    historyMax, autoClearHistoryDays
    appPin (4-digit, lightly obfuscated)
    autoLockMin (0|1|5|10|30|60)
    dailyReminder, importNotif
  folders/{fid}/
    id, name, description, tags[]
    pinned, locked, pin (6-digit)
    linkCount, color, icon, iconUrl
    createdAt, updatedAt
    links/{lid}/
      id, url, title, domain, favicon, thumbnailUrl
      liked, disliked, starred, blocked, pinned
      openCount, points
      addedAt, updatedAt, folderId, folderName
  recycleBin/{id}/
    type: 'folder'|'link'
    originalId|originalFid|originalLid
    data (snapshot), deletedAt, expireAt
  history/{id}/
    url, title, domain, favicon
    openedAt, folderId, folderName, source
```

---

## Design System Tokens

| Token | Value | Usage |
|-------|-------|-------|
| `--primary` | `#3b82f6` | Primary blue |
| `--secondary` | `#22d3ee` | Cyan accent |
| `--gradient` | `135deg, #3b82f6 → #22d3ee` | Brand gradient |
| `--font-ui` | `Outfit, DM Sans` | All UI text |
| `--r-md` | `12px` | Standard border radius |
| `--r-xl` | `20px` | Cards, modals |
| `--sp-4` | `16px` | Standard spacing |

---

## SEO & Meta

```html
<title>Linkivo — Smart Link Manager</title>
<meta name="description" content="Save, organize, and randomly discover links. Import from 10+ formats, folder organization, point-based discovery, PWA.">
<meta name="keywords" content="link manager, bookmark manager, link organizer, save links, random link discovery, PWA, Firebase">
<meta name="author" content="Linkivo">

<!-- Open Graph -->
<meta property="og:title" content="Linkivo — Smart Link Manager">
<meta property="og:description" content="Smart link management with random discovery, 10+ import formats, and cross-device sync.">
<meta property="og:image" content="https://linkivo.web.app/assets/og-image.png">
<meta property="og:url" content="https://linkivo.web.app">
<meta property="og:type" content="website">

<!-- Twitter -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="@linkivo_app">
<meta name="twitter:title" content="Linkivo — Smart Link Manager">
<meta name="twitter:description" content="Smart link management with random discovery.">
<meta name="twitter:image" content="https://linkivo.web.app/assets/og-image.png">
```

---

## Changelog Reference

| Version | Date | Highlights |
|---------|------|-----------|
| v1.0.0 | 2025-03 | Initial release: auth, folder CRUD, basic UI |
| v1.1.0 | 2025-09 | Import engine (10+ formats) |
| v1.2.0 | 2025-11 | Random discover, point system, history |
| v1.3.0 | 2026-01 | Settings, export, PIN lock, recycle bin |
| v1.4.0 | 2026-03-27 | PWA, service worker, offline support |
| v1.4.2 | 2026-03-31 | Bug fixes: calcLinkPoints single source, history clear fix |
| v1.4.4 | 2026-04-01 | Tab overlap fix, splash fix, SW update, sidebar logo toggle, locked folder DOM security |
| **v1.4.5** | 2026-04-05 | Global search, gradient logo, profile overhaul, imgbb, full-page recycle bin, path routing, history undo, forget PIN, preview fallback chain |

---

## Author / Credits

| Role | Name |
|------|------|
| Developer / Designer | Muhtasim Rahman |
| App Icon | Custom SVG (paths: left ring, right ring, connector, link bar) |
| Contact | linkivo.web@gmail.com |
| Copyright | © 2026 Linkivo. All rights reserved. |
| License | MIT |

---

## Env Variables Reference

> **Never commit `firebase-config.js`** — it is gitignored.

```js
// firebase-config.js (gitignored, never deployed directly)
const firebaseConfig = {
  apiKey:            "...",
  authDomain:        "...",
  projectId:         "...",
  storageBucket:     "...",
  messagingSenderId: "...",
  appId:             "...",
  measurementId:     "...",
  databaseURL:       "..."
};
```

```
// Cloudflare Workers proxy
IMGBB_UPLOAD_URL = https://linkivo.programs-turzo.workers.dev/
// Variable name in Worker: imgbb_api (encrypted in Cloudflare dashboard)
```

---

## PWA Manifest Key Values

```json
{
  "name": "Linkivo",
  "short_name": "Linkivo",
  "theme_color": "#3b82f6",
  "background_color": "#0f172a",
  "display": "standalone",
  "orientation": "portrait",
  "start_url": "/",
  "scope": "/"
}
```
