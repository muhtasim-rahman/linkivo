/**
 * Linkivo — Cloudflare Worker: ImgBB Proxy
 * 
 * Deployed at: https://linkivo.programs-turzo.workers.dev/
 * 
 * Purpose: Proxies image uploads to ImgBB API without exposing
 *   the API key to the client. The API key is stored as an
 *   encrypted Worker secret named `imgbb_api`.
 * 
 * Request:  POST multipart/form-data
 *   - image: base64-encoded image string (data: prefix stripped)
 *   - name:  filename for the uploaded image
 * 
 * Response: { data: { url: "https://i.ibb.co/..." } }
 * 
 * CORS: Allow linkivo.web.app + localhost
 */

export default {
  async fetch(request, env) {
    // ── CORS preflight ────────────────────────────────────
    const origin = request.headers.get('Origin') || '';
    const allowed = [
      'https://linkivo.web.app',
      'https://linkivo.firebaseapp.com',
      'http://localhost:5000',
      'http://127.0.0.1:5000',
    ];
    const corsOrigin = allowed.includes(origin) ? origin : allowed[0];

    const corsHeaders = {
      'Access-Control-Allow-Origin':  corsOrigin,
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
      'Access-Control-Max-Age':       '86400',
    };

    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders });
    }

    if (request.method !== 'POST') {
      return new Response(JSON.stringify({ error: 'Method not allowed' }), {
        status: 405,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // ── Parse incoming form data ──────────────────────────
    let formData;
    try {
      formData = await request.formData();
    } catch {
      return new Response(JSON.stringify({ error: 'Invalid form data' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const image = formData.get('image');
    const name  = formData.get('name') || 'linkivo-upload';

    if (!image) {
      return new Response(JSON.stringify({ error: 'Missing image field' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // ── Forward to ImgBB ──────────────────────────────────
    const apiKey = env.imgbb_api; // encrypted secret in Cloudflare dashboard

    const imgbbForm = new FormData();
    imgbbForm.append('key',   apiKey);
    imgbbForm.append('image', image);
    imgbbForm.append('name',  name);

    let imgbbRes;
    try {
      imgbbRes = await fetch('https://api.imgbb.com/1/upload', {
        method: 'POST',
        body:   imgbbForm,
      });
    } catch (err) {
      return new Response(JSON.stringify({ error: 'ImgBB unreachable', detail: err.message }), {
        status: 502,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const result = await imgbbRes.json();

    return new Response(JSON.stringify(result), {
      status:  imgbbRes.status,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  },
};
