# Linkivo v1.4.5 — Deploy & Setup Guide

## 1. Firebase Config
Copy `firebase-config.example.js` → `firebase-config.js` and fill in your values:
```js
const firebaseConfig = {
  apiKey:            "YOUR_API_KEY",
  authDomain:        "YOUR_PROJECT.firebaseapp.com",
  projectId:         "YOUR_PROJECT",
  storageBucket:     "YOUR_PROJECT.firebasestorage.app",
  messagingSenderId: "...",
  appId:             "...",
  measurementId:     "...",
  databaseURL:       "https://YOUR_PROJECT-default-rtdb.firebaseio.com"
};
export default firebaseConfig;
```

## 2. Firebase Database Rules
In Firebase Console → Realtime Database → Rules:
```json
{
  "rules": {
    "users": {
      "$uid": {
        ".read": "$uid === auth.uid",
        ".write": "$uid === auth.uid"
      }
    }
  }
}
```

## 3. Enable Auth Providers
Firebase Console → Authentication → Sign-in method → Enable:
- Google
- Email/Password

## 4. Deploy
```bash
npm install -g firebase-tools
firebase login
firebase deploy --only hosting
```

## 5. Cloudflare Worker (imgbb proxy)
See `cloudflare-worker.js` in this folder.

### Steps:
1. Go to https://dash.cloudflare.com → Workers & Pages → Create
2. Paste the worker code
3. Go to Settings → Variables → Add secret:
   - Name: `imgbb_api`
   - Value: your ImgBB API key (from https://api.imgbb.com)
4. Deploy — note the worker URL
5. Update `IMGBB_PROXY` in `assets/js/utils.js` if your URL differs

## 6. Run Locally
```bash
firebase serve
# or
npx serve .
```
Open http://localhost:5000

## 7. .gitignore
`firebase-config.js` is gitignored — never commit it.

## 8. PWA Icons (optional, for better mobile experience)
Generate PNG icons from `assets/svg/app-icon.svg`:
- 192×192 → `assets/icons/icon-192.png`
- 512×512 → `assets/icons/icon-512.png`

Use https://realfavicongenerator.net or similar tool.

## Contact
linkivo.web@gmail.com
